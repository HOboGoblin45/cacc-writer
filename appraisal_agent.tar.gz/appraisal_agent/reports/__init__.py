from .generator import ReportGenerator
